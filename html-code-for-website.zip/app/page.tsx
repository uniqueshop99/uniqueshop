"use client"

import { useState, useEffect } from "react"
import { X, ChevronLeft, ChevronRight, Facebook, Instagram, Youtube, Mail, Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"

const products = [
  { id: 1, title: "Free Fire UID Topup [BD SERVER]", badge: "Hot" },
  { id: 2, title: "UNIPIN VOUCHER (BDT)", badge: null },
  { id: 3, title: "Weekly Lite [BD Server]", badge: "New" },
  { id: 4, title: "Weekly & Monthly [Offer]", badge: "Sale" },
  { id: 5, title: "UID Evo Access", badge: null },
  { id: 6, title: "Level Up Pass", badge: "Popular" },
]

const bannerSlides = [
  {
    id: 1,
    title: "ইউনিক শপ থেকে",
    subtitle: "সকল আপডেট ও গিভওয়ে",
    description: "যুক্ত থাকুন আমাদের",
    highlight: "টেলিগ্রাম গ্রুপ",
  },
  {
    id: 2,
    title: "সেরা দামে পান",
    subtitle: "গেম টপ-আপ সার্ভিস",
    description: "দ্রুত ও নিরাপদ",
    highlight: "২৪/৭ সাপোর্ট",
  },
  {
    id: 3,
    title: "বিশেষ অফার",
    subtitle: "এখনই অর্ডার করুন",
    description: "সীমিত সময়ের জন্য",
    highlight: "২০% ছাড়",
  },
]

export default function HomePage() {
  const [showNotice, setShowNotice] = useState(true)
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % bannerSlides.length)
    }, 4000)
    return () => clearInterval(timer)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % bannerSlides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + bannerSlides.length) % bannerSlides.length)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">U</span>
            </div>
            <span className="text-xl font-bold">
              <span className="text-emerald-600">Unique</span>{" "}
              <span className="text-slate-800">SHOP</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              Login
            </Button>
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white">
              Register
            </Button>
          </div>
        </div>
      </header>

      {/* Notice Bar */}
      {showNotice && (
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-3 relative">
          <div className="container mx-auto pr-8">
            <p className="text-sm font-medium">
              <span className="font-bold">Notice:</span> Unique Shop এ ১২ ঘন্টা টিকপন্ট তত্বু থাকে....!!! যেকোনো সমস্যা সমাধান করতেছে{" "}
              <span className="font-bold underline">WhatsApp</span> এ মেসেজ দিন।
            </p>
          </div>
          <button
            onClick={() => setShowNotice(false)}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-white/20 rounded-full transition-colors"
            aria-label="Close notice"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hero Banner Slider */}
      <section className="relative overflow-hidden">
        <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 py-8 px-4">
          <div className="container mx-auto relative">
            {/* Badge */}
            <div className="absolute top-0 left-0 z-10">
              <span className="bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                ২৪ ঘন্টা সেবা
              </span>
            </div>

            {/* Slider Content */}
            <div className="relative min-h-[180px] flex items-center justify-center text-center py-8">
              <div className="space-y-2">
                <p className="text-white/80 text-sm">{bannerSlides[currentSlide].title}</p>
                <h2 className="text-2xl md:text-3xl font-bold text-white">
                  {bannerSlides[currentSlide].subtitle}
                </h2>
                <p className="text-lg text-white/90">{bannerSlides[currentSlide].description}</p>
                <p className="text-emerald-400 font-bold text-xl">{bannerSlides[currentSlide].highlight}</p>
                <Button className="mt-4 bg-emerald-500 hover:bg-emerald-600 text-white">
                  Join Now
                </Button>
              </div>

              {/* Navigation Arrows */}
              <button
                onClick={prevSlide}
                className="absolute left-0 top-1/2 -translate-y-1/2 p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
                aria-label="Previous slide"
              >
                <ChevronLeft className="w-5 h-5 text-white" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-0 top-1/2 -translate-y-1/2 p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
                aria-label="Next slide"
              >
                <ChevronRight className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Dots Indicator */}
            <div className="flex justify-center gap-2 mt-4">
              {bannerSlides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    currentSlide === index ? "bg-white" : "bg-white/40"
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Games Top Up Section */}
      <section className="py-8 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="h-0.5 w-12 bg-gradient-to-r from-transparent to-emerald-500" />
            <h2 className="text-xl font-bold text-slate-800">GAMES TOP UP</h2>
            <div className="h-0.5 w-12 bg-gradient-to-l from-transparent to-emerald-500" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((product) => (
              <div
                key={product.id}
                className="group relative bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer border border-border hover:border-emerald-300"
              >
                {product.badge && (
                  <span className={`absolute top-2 left-2 z-10 text-xs font-bold px-2 py-1 rounded-full ${
                    product.badge === "Hot" ? "bg-red-500 text-white" :
                    product.badge === "New" ? "bg-blue-500 text-white" :
                    product.badge === "Sale" ? "bg-orange-500 text-white" :
                    "bg-emerald-500 text-white"
                  }`}>
                    {product.badge}
                  </span>
                )}
                <div className="aspect-[4/3] bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-blue-600/20" />
                  <div className="relative z-10 text-center p-4">
                    <div className="w-16 h-16 mx-auto bg-gradient-to-br from-emerald-400 to-teal-500 rounded-xl flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                      <span className="text-2xl font-bold text-white">
                        {product.title.charAt(0)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="p-3 text-center">
                  <h3 className="text-sm font-semibold text-slate-800 line-clamp-2 group-hover:text-emerald-600 transition-colors">
                    {product.title}
                  </h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* App Download Banner */}
      <section className="px-4 py-6">
        <div className="container mx-auto">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-6 flex items-center gap-4">
            <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center shrink-0">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">U</span>
              </div>
            </div>
            <div className="flex-1">
              <p className="text-white font-bold">Download our mobile app now</p>
              <p className="text-emerald-100 text-sm">Download Now →</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white">
        {/* Stay Connected */}
        <div className="border-b border-slate-700">
          <div className="container mx-auto px-4 py-8">
            <h3 className="text-lg font-bold mb-2">STAY CONNECTED</h3>
            <p className="text-slate-400 text-sm mb-4">
              কোন সমস্যায় পড়লে যোগাযোগসূত্র এ যোগাযোগ করবেন। আমরা দ্রুত সমাধান দেওয়ে থাকি।
            </p>
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-slate-800 hover:bg-emerald-600 rounded-full flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-slate-800 hover:bg-emerald-600 rounded-full flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-slate-800 hover:bg-emerald-600 rounded-full flex items-center justify-center transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-slate-800 hover:bg-emerald-600 rounded-full flex items-center justify-center transition-colors"
                aria-label="Email"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile App */}
        <div className="border-b border-slate-700">
          <div className="container mx-auto px-4 py-8">
            <h3 className="text-lg font-bold mb-4">OUR MOBILE APP</h3>
            <a
              href="#"
              className="inline-flex items-center gap-3 bg-slate-800 hover:bg-slate-700 px-4 py-3 rounded-xl transition-colors"
            >
              <div className="w-8 h-8">
                <svg viewBox="0 0 24 24" className="w-full h-full fill-current">
                  <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.53,12.9 20.18,13.18L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z" />
                </svg>
              </div>
              <div>
                <p className="text-xs text-slate-400">GET IT ON</p>
                <p className="font-bold">Google Play</p>
              </div>
            </a>
          </div>
        </div>

        {/* Support Center */}
        <div className="border-b border-slate-700">
          <div className="container mx-auto px-4 py-8">
            <h3 className="text-lg font-bold mb-4">SUPPORT CENTER</h3>
            <div className="flex items-center gap-4 bg-slate-800 p-4 rounded-xl">
              <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                <Headphones className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium">Help line [9AM-12PM]</p>
                <p className="text-emerald-400 font-bold">01306698625</p>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="container mx-auto px-4 py-6 text-center">
          <p className="text-slate-400 text-sm">
            © Copyright 2024. All Rights Reserved. Developed by{" "}
            <span className="text-emerald-400 font-semibold">Unique Shop</span>
          </p>
        </div>
      </footer>
    </div>
  )
}
